package de.kipf.shop.teile.db;

public class TeiltypNotFoundException extends Exception {
	private static final long serialVersionUID = -3642207745872873594L;

	public TeiltypNotFoundException(String string) {
		super(string);
	}

}
