package de.kipf.shop.teile;

public interface LagerverwaltungLocal extends Lagerverwaltung {

}
