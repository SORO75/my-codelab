package de.kipf.shop.teile;

public interface ModellverwaltungLocal extends Modellverwaltung {

}
