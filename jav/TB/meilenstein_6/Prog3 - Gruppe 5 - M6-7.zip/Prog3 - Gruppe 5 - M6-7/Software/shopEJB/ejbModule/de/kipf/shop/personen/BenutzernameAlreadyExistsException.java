package de.kipf.shop.personen;

//TODO Klasse �berarbeiten!
public class BenutzernameAlreadyExistsException extends Exception {

	private static final long serialVersionUID = -1159143638311111079L;

}
