package de.kipf.shop.vorgaenge;

public class WarenkorbNotFoundException extends Exception {
	private static final long serialVersionUID = 3910896235993038756L;

	public WarenkorbNotFoundException(String str) {
		super(str);
	}
}
