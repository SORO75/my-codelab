package de.kipf.shop.personen;

//TODO Klasse �berarbeiten!
public class BenutzernameNotValidException extends Exception {

	private static final long serialVersionUID = -5732634322879837066L;

}
