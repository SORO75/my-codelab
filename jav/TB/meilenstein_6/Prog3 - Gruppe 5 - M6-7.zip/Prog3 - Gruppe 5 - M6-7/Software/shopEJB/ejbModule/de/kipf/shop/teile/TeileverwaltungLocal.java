package de.kipf.shop.teile;

public interface TeileverwaltungLocal {

}
