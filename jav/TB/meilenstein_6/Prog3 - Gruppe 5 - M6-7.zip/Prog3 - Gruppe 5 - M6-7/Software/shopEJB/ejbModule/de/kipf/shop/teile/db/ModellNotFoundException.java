package de.kipf.shop.teile.db;

public class ModellNotFoundException extends Exception {
	private static final long serialVersionUID = 3808989849278208961L;

	public ModellNotFoundException(String str) {
		super(str);
	}
}
