package de.kipf.shop.vorgaenge;

public interface WarenkorbverwaltungLocal {

}
