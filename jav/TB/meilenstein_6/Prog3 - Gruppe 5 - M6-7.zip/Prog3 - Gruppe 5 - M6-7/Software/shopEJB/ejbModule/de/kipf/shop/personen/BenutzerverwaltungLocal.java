package de.kipf.shop.personen;

public interface BenutzerverwaltungLocal extends Benutzerverwaltung {

}
