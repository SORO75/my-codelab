SET search_path TO shop;

DROP TABLE benutzergruppe CASCADE;
DROP TABLE auftragsstatustyp CASCADE;
DROP TABLE lager CASCADE;
DROP TABLE teiltyp CASCADE;
DROP TABLE fahrradtyp CASCADE;
DROP TABLE modell_einzelteil CASCADE;
DROP TABLE warenkorb_position CASCADE;
DROP TABLE auftragsstatus CASCADE;
DROP TABLE warenkorb CASCADE;
DROP TABLE modell CASCADE;
DROP TABLE benutzer CASCADE;
DROP TABLE benutzer_gruppe CASCADE;
DROP TABLE einzelteil CASCADE;
DROP TABLE auftrag CASCADE;






